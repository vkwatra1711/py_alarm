import rclpy
from rclpy.node import Node

from std_msgs.msg import String
import datetime


class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('Minimal_Publisher')
        self.subscription = self.create_subscription(String, '/clock/setalarm', self.listener_callback, 10)
        self.subscription

    def listener_callback(self, msg):
        self.j = datetime.datetime.now()
        time_now = '%s:%s:%s' % (self.j.hour, self.j.minute, self.j.second)

        if time_now < msg.data:
            self.get_logger().info('The alarm has been initiated at: "%s"' % msg.data)
            
        if time_now > msg.data:
            self.get_logger().info('You have set an alarm of wrong time. The current time is "%s"' % time_now)

        if time_now == msg.data:
            self.publisher_ = self.create_publisher(String, '/clock/alarm', 10)
            timer_period = 1
            msg = String()
            msg.data = '%s:%s:%s' % (self.j.hour, self.j.minute, self.j.second)
            self.publisher_.publish(msg)
            
            self.get_logger().info('The alarm will start at"%s"' % msg.data)


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()
    rclpy.spin(minimal_publisher)
    minimal_publisher.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()

