import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from datetime import datetime

class MinimalSubscriber(Node):

    def __init__(self):
        super().__init__('Minimal_Subscriber')        
        self.publisher_ = self.create_publisher(String, '/clock/setalarm', 10)
        timer_period = 1
        self.timer = self.create_timer(timer_period, self.timer_callback)
        
        time=input("What time you want the alarm: ")
        self.i =datetime.strptime(time,"%H:%M:%S")
        self.j = datetime.now()
        
    def timer_callback(self):
        msg = String()
        msg.data = '%s:%s:%s' %(self.i.hour,self.i.minute,self.i.second)
        time_now = '%s:%s:%s' %(self.j.hour,self.j.minute,self.j.second)
        self.publisher_.publish(msg)
        if time_now < msg.data:
        	self.get_logger().info('The alarm is set at: "%s"' % msg.data)
        if time_now > msg.data:
            self.get_logger().info('You have set an alarm of wrong time. The current time is "%s"' % time_now)
        self.subscription = self.create_subscription(
            String,
            '/clock/alarm',
            self.listener_callback,
            10)
        self.subscription  

    def listener_callback(self, msg):
        self.get_logger().info('Now the time is:"%s"'%msg.data)
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
	
    minimal_subscriber = MinimalSubscriber()
    rclpy.spin(minimal_subscriber)
    minimal_subscriber.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()


